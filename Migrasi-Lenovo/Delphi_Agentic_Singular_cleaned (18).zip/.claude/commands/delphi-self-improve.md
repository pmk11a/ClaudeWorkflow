# Delphi Migration Self-Improve

**Purpose**: Auto-update expertise.yaml setelah migrasi selesai

---

## ⏰ KAPAN DIJALANKAN?

```
┌─────────────────────────────────────────────────────────────────┐
│                    MIGRATION COMPLETION SIGNALS                 │
│                                                                 │
│  ✅ MIGRASI SELESAI jika:                                      │
│     1. Validation tools pass (0 errors)                        │
│     2. User sudah TEST di browser                              │
│     3. User bilang: "OK" / "Working" / "Lanjut" / "Done"       │
│                                                                 │
│  ❌ BELUM SELESAI jika:                                        │
│     - Masih ada error saat generate                            │
│     - User belum test                                          │
│     - User bilang: "Error" / "Fix ini" / "Ada bug"             │
└─────────────────────────────────────────────────────────────────┘
```

### Trigger Phrases (User Approval):

| User Says | Action |
|-----------|--------|
| "OK", "Oke", "Working", "Bagus" | ✅ Run self-improve |
| "Lanjut", "Next", "Done", "Selesai" | ✅ Run self-improve |
| "LGTM", "Ship it", "Merge" | ✅ Run self-improve |
| "Error", "Bug", "Fix", "Salah" | ❌ Fix dulu, jangan run |

---

## Usage

```
/delphi-self-improve
```

**Tidak perlu argument** - Agent auto-extract dari conversation:
- Module & Form name
- Duration (dari timestamps)
- Issues encountered (dari error messages)
- Patterns used (dari code generated)

---

## Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                    SELF-IMPROVE WORKFLOW                        │
│                                                                 │
│  1. SCAN conversation history                                  │
│     - Extract module/form yang dimigrasi                       │
│     - Extract errors yang terjadi                              │
│     - Extract patterns yang digunakan                          │
│     - Estimate duration                                        │
│                                                                 │
│  2. READ current expertise.yaml                                │
│                                                                 │
│  3. COMPARE & IDENTIFY                                         │
│     - New issues? (not in known_issues)                        │
│     - New patterns? (not in core_patterns)                     │
│     - Existing issues re-encountered?                          │
│                                                                 │
│  4. UPDATE expertise.yaml                                      │
│     - Add to completed_migrations                              │
│     - Add new issues to known_issues (auto-generate ID)        │
│     - Update confidence metrics                                │
│                                                                 │
│  5. REPORT summary to user                                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Auto-Detection Rules

### Module & Form Detection
```
Scan for:
- "FrmXXX.pas" atau "FrmXXX.dfm" dalam conversation
- Controller/Service/Model yang digenerate
- Route yang ditambahkan
```

### Issue Detection
```
Scan for:
- Error messages (SQLSTATE, Exception, Error:)
- "Fix:", "Fixed:", "Solved:"
- User complaints lalu resolution
```

### Pattern Detection
```
Scan for generated code:
- Choice:Char → mode_operations
- IsTambah/IsKoreksi → permission_system
- LoggingData → audit_logging
- OL/Otorisasi → authorization_levels
- Detail/Items → master_detail
```

---

## Update Rules

### New Issue (Auto-ID)
```yaml
# Jika error baru ditemukan, generate ID otomatis:
- id: "ISSUE-006"  # increment dari last ID di expertise.yaml
  title: "[extracted from error]"
  symptom: "[error message]"
  cause: "[dari conversation]"
  solution: "[dari fix yang dilakukan]"
  severity: "medium"  # default
  encountered_in: ["MODULE"]
```

### Completed Migration Entry
```yaml
- module: "XXX"
  form: "FrmXXX"
  complexity: "MEDIUM"  # infer dari duration
  date: "YYYY-MM-DD"
  duration_hours: X.X
  patterns_used: [auto-detected]
  issues_encountered: [auto-detected]
  notes: "[summary dari conversation]"
```

### Complexity Inference
```
duration < 2 hours → SIMPLE
duration 2-5 hours → MEDIUM
duration > 5 hours → COMPLEX
```

---

## Output Example

```markdown
## ✅ Self-Improve Complete

### Migration Recorded
- **Module**: SPK
- **Form**: FrmSPK
- **Duration**: 4.5 hours
- **Complexity**: MEDIUM
- **Patterns**: mode_operations, permission_system, master_detail

### Issues Logged
- **ISSUE-006** (NEW): NULL constraint on TglKirim field
  - Symptom: Cannot insert NULL into column 'TglKirim'
  - Solution: Use empty string for NOT NULL varchar

### Expertise Updated
- Total migrations: 5
- Known issues: 6
- Success rate: 100%
```

---

## Important Notes

1. **Zero user input required** - Agent extracts everything from context
2. Run after user approval, not after every fix
3. New issues get auto-generated IDs
4. Confidence metrics auto-recalculate
