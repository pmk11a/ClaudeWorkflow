---
name: delphi-laravel-migration
version: 2.3.0
description: Migrate Delphi VCL applications to modern Laravel by extracting business logic, permissions, validation rules, and mode-dependent operations from Delphi source files (.dfm, .pas) and generating production-ready Laravel code with services, controllers, requests, and policies.
---

# Delphi to Laravel Migration Skill v2.3

Transform your legacy Delphi applications into modern Laravel applications with **rigorous business logic preservation**.

**This skill implements the Agent Expert pattern** - it learns from every migration and improves over time.

---

## 🧠 AGENT EXPERT PATTERN

This skill is not just a tool - it's an **Agent Expert** that:

```
┌─────────────────────────────────────────────────────────────────┐
│                     AGENT EXPERT LIFECYCLE                      │
│                                                                 │
│   ┌─────────┐      ┌─────────┐      ┌─────────┐               │
│   │  READ   │ ───▶ │  ACT    │ ───▶ │  LEARN  │               │
│   │expertise│      │(migrate)│      │(improve)│               │
│   └─────────┘      └─────────┘      └─────────┘               │
│        ▲                                  │                    │
│        │                                  │                    │
│        └──────────────────────────────────┘                    │
│                   (cycle repeats)                              │
└─────────────────────────────────────────────────────────────────┘
```

### Mental Model: expertise.yaml

The agent's "brain" is stored in `expertise.yaml`:

```yaml
# What agent knows:
core_patterns:      # Delphi→Laravel mappings
known_issues:       # Problems encountered & solved
completed_migrations: # Track record
confidence:         # Self-assessed accuracy
learning_queue:     # Topics to investigate
```

### Key Difference from Generic Agents:

| Generic Agent | Agent Expert |
|---------------|--------------|
| Execute & forget | Execute & learn |
| Re-learn every task | Accumulate expertise |
| Manual updates | Auto-update via self-improve |
| Static knowledge | Evolving mental model |

---

## 🚀 PRIME COMMAND (Quick Start)

**Untuk memulai migrasi, gunakan command ini:**

```
/delphi-laravel-migration "FrmXXX.pas FrmXXX.dfm"
```

**Atau langsung dengan prompt:**
```
Migrasi FrmPO.pas dan FrmPO.dfm ke Laravel. Ikuti SOP di skill delphi-migration.
```

### Apa yang terjadi saat Prime Command dijalankan:

```
┌─────────────────────────────────────────────────────────────────┐
│ 0. LOAD MENTAL MODEL (Agent Expert)                            │
│    └─ Baca expertise.yaml (known issues, patterns, confidence) │
│                                                                 │
│ 1. LOAD CONTEXT                                                 │
│    ├─ Baca CLAUDE.md (project context)                         │
│    ├─ Baca SKILL.md (entry point)                              │
│    └─ Baca RULES.md (constraints + SOLID)                      │
│                                                                 │
│ 2. ANALYZE                                                      │
│    ├─ Parse .pas file dengan pas_parser_enhanced.py            │
│    ├─ Parse .dfm file dengan dfm_parser_enhanced.py            │
│    ├─ Detect patterns (Choice:Char, permissions, validations)  │
│    └─ Compare with expertise.yaml (validate mental model)      │
│                                                                 │
│ 3. PLAN                                                         │
│    ├─ Baca PATTERN-GUIDE.md untuk mapping                      │
│    ├─ Baca SOP-DELPHI-MIGRATION.md untuk prosedur              │
│    ├─ Check known_issues for potential problems                │
│    └─ Buat migration plan (USER APPROVAL REQUIRED)             │
│                                                                 │
│ 4. GENERATE                                                     │
│    ├─ Controller, Service, Request, Policy, Views              │
│    ├─ Ikuti RULES.md (SOLID principles)                        │
│    └─ Generate tests                                            │
│                                                                 │
│ 5. VALIDATE (Self-Correcting Loop)                             │
│    ├─ Run tools/validate_migration.php                         │
│    ├─ If errors → Fix → Re-validate                            │
│    └─ Until all validations pass                               │
│                                                                 │
│ 6. LEARN (Self-Improve)                                        │
│    ├─ Run /delphi-self-improve                                 │
│    ├─ Update expertise.yaml with new knowledge                 │
│    └─ Log issues encountered & solutions                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔄 SELF-CORRECTING LOOP

Skill ini menggunakan **closed-loop validation** untuk memastikan kualitas output:

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   GENERATE   │────▶│   VALIDATE   │────▶│    CHECK     │
│     Code     │     │  with tools  │     │   Results    │
└──────────────┘     └──────────────┘     └──────┬───────┘
       ▲                                         │
       │                                         ▼
       │                                  ┌──────────────┐
       │         ┌──────────────┐         │   ERRORS?    │
       └─────────│     FIX      │◀────YES─│              │
                 │    Issues    │         └──────┬───────┘
                 └──────────────┘                │ NO
                                                 ▼
                                          ┌──────────────┐
                                          │   ✅ DONE    │
                                          │   Ship it!   │
                                          └──────────────┘
```

### Validation Tools Available:

| Tool | Purpose | Command |
|------|---------|---------|
| `validate_migration.php` | Check validation coverage | `php tools/validate_migration.php <module> <form>` |
| `extract_validation_rules.php` | Extract Delphi rules | `php tools/extract_validation_rules.php <form>` |
| `verify-migration.php` | Final verification | `php tools/verify-migration.php` |

### ADW Scripts (AI Developer Workflows):

| Script | Purpose | Command |
|--------|---------|---------|
| `adw-migration.sh` | Full migration pipeline | `./scripts/adw/adw-migration.sh <module>` |
| `adw-validation.sh` | Validation only | `./scripts/adw/adw-validation.sh <module>` |
| `adw-review.sh` | Code review pipeline | `./scripts/adw/adw-review.sh` |

### Self-Correction Process:

```bash
# Step 1: Generate code
/delphi-laravel-migration "FrmPO.pas FrmPO.dfm"

# Step 2: Validate (automatic atau manual)
php tools/validate_migration.php PO FrmPO

# Step 3: Jika ada error, Claude akan:
#   - Baca error message
#   - Cek OBSERVATIONS.md untuk similar issues
#   - Fix the code
#   - Re-run validation

# Step 4: Loop sampai semua validasi pass
```

### Validation Checkpoints:

| Checkpoint | Tool | Pass Criteria |
|------------|------|---------------|
| Mode Coverage | validate_migration | 100% I/U/D detected |
| Permission Coverage | validate_migration | 100% IsTambah/IsKoreksi/IsHapus |
| Validation Coverage | validate_migration | ≥95% rules mapped |
| Code Quality | pint + phpstan | No errors |
| Tests | phpunit | All pass |

---

## 🚨 REQUIRED READING (Wajib Baca Sebelum Mulai)

**Claude HARUS membaca file-file ini sesuai urutan sebelum melakukan migrasi:**

### Priority 1: WAJIB (Sebelum generate code)
```
1. RULES.md              ← Aturan + SOLID principles (BACA PERTAMA!)
2. PATTERN-GUIDE.md      ← Pattern detection Delphi→Laravel
3. SOP-DELPHI-MIGRATION.md ← Prosedur step-by-step
```

### Priority 2: REFERENSI (Saat generate code)
```
4. QUICK-REFERENCE.md    ← Cheatsheet cepat
5. KNOWLEDGE-BASE.md     ← Domain knowledge detail
```

### Priority 3: LESSONS LEARNED (Hindari kesalahan)
```
6. OBSERVATIONS.md       ← Pelajaran dari migrasi sebelumnya
7. ai_docs/lessons/      ← Case-specific fixes (baca jika relevan)
```

**Lessons tersedia di ai_docs/lessons/:**
- `AUTHORIZATION_NULLS_CONSTRAINT_FIX.md` - Fix NULL constraint di authorization
- `BARANG_MIGRATION_COLUMN_NAMES_FIX.md` - Fix column names migration
- `MULTI_LEVEL_AUTHORIZATION.md` - Implementasi multi-level auth
- `PPL_LOCKPERIODE_IMPLEMENTATION.md` - Lock periode implementation
- `PPL_PODET_VALIDATION_FIX.md` - Validation fix untuk PODET
- `WHY_SKILL_MISSED_NULL_CONSTRAINT.md` - Kenapa NULL constraint terlewat

### ⚠️ JANGAN SKIP!
- Jika skip RULES.md → Code tidak SOLID compliant
- Jika skip PATTERN-GUIDE.md → Pattern tidak terdeteksi
- Jika skip OBSERVATIONS.md → Ulangi kesalahan lama

---

## What's New in v2.3

✅ **Agent Expert Pattern** - Skill yang belajar dari setiap migrasi
✅ **expertise.yaml** - Mental model file untuk accumulated knowledge
✅ **Self-Improve Command** - Auto-update expertise setelah migrasi
✅ **Prime Command** - Quick start dengan mental model loading
✅ **Self-Correcting Loop** - Closed-loop validation dengan tools
✅ **ADW Integration** - AI Developer Workflows terintegrasi

✅ **Full Pattern Detection** - Choice:Char, permissions, LoggingData, all 8 validation patterns  
✅ **Request Classes** - Separate Store/Update/Delete request classes  
✅ **Service Layer** - Mode-based operations with audit logging  
✅ **Policy Classes** - Permission mapping from Delphi  
✅ **Laravel Structure** - Proper directory layout  

## Quick Start

### 1. Analyze Your Delphi Form

```bash
python delphi-migrate-enhanced.py analyze FrmAktiva.pas
```

This will show:
- Detected permissions (IsTambah, IsKoreksi, IsHapus)
- Choice:Char procedures with modes (I/U/D)
- Validation rules found
- LoggingData calls

### 2. Run Full Migration

```bash
python delphi-migrate-enhanced.py migrate FrmAktiva.pas --model Aktiva
```

This generates:
- `app/Http/Controllers/AktivaController.php`
- `app/Http/Requests/Aktiva/StoreAktivaRequest.php`
- `app/Http/Requests/Aktiva/UpdateAktivaRequest.php`
- `app/Services/AktivaService.php`
- `app/Policies/AktivaPolicy.php`
- `app/Support/AuditLog.php`
- `routes/aktiva_routes.php`

### 3. Verify Generated Files

```bash
python delphi-migrate-enhanced.py verify
```

## Pattern Detection

### Mode-Based Operations (Choice:Char)

**Delphi:**
```pascal
Procedure TFrAktiva.UpdateDataAktiva(Choice:Char);
begin
  if Choice='I' then  // INSERT
    // ...
  else if Choice='U' then  // UPDATE
    // ...
  else if Choice='D' then  // DELETE
    // ...
end;
```

**Generated Laravel:**
- `store()` method → Choice='I'
- `update()` method → Choice='U'  
- `destroy()` method → Choice='D'

### Permission Mapping

| Delphi | Laravel Request | Laravel Policy |
|--------|-----------------|----------------|
| `IsTambah` | `StoreRequest::authorize()` | `Policy::create()` |
| `IsKoreksi` | `UpdateRequest::authorize()` | `Policy::update()` |
| `IsHapus` | - | `Policy::delete()` |
| `IsCetak` | - | `Policy::print()` |
| `IsExcel` | - | `Policy::export()` |

### Validation Patterns

| Pattern | Delphi | Laravel |
|---------|--------|---------|
| Range | `if Value < 0 then` | `min:0` |
| Unique | `if QuCheck.Locate(...)` | `unique:table,field` |
| Required | `if Text = '' then` | `required` |
| Format | `if not IsValidDate(...)` | `date_format:Y-m-d` |
| Lookup | `if not QuTable.Locate(...)` | `exists:table,field` |
| Conditional | `if Type=1 then if Field...` | `required_if:type,1` |
| Enum | `if not (Status in [...])` | `in:A,B,C` |
| Custom | `raise Exception.Create(...)` | `withValidator()` |

### Audit Logging

**Delphi:**
```pascal
LoggingData(IDUser, Choice, 'Aktiva', NoBukti, Keterangan);
```

**Generated Laravel:**
```php
AuditLog::log('I', 'Aktiva', $noBukti, auth()->id(), $keterangan);
```

## Generated Code Structure

```
output/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   └── AktivaController.php    # Uses Service, FormRequest
│   │   └── Requests/
│   │       └── Aktiva/
│   │           ├── StoreAktivaRequest.php   # INSERT validation
│   │           ├── UpdateAktivaRequest.php  # UPDATE validation
│   │           └── DeleteAktivaRequest.php  # DELETE validation
│   ├── Models/
│   │   └── Aktiva.php
│   ├── Policies/
│   │   └── AktivaPolicy.php           # Permission checks
│   ├── Services/
│   │   └── AktivaService.php          # Business logic
│   └── Support/
│       └── AuditLog.php               # Logging helper
├── database/
│   └── migrations/
│       └── create_log_activity_table.php
└── routes/
    └── aktiva_routes.php
```

## CLI Commands

```bash
# Analyze PAS file
python delphi-migrate-enhanced.py analyze <file.pas>

# Full migration
python delphi-migrate-enhanced.py migrate <file.pas> [--model Name] [--output dir]

# Generate only requests
python delphi-migrate-enhanced.py generate-requests <file.pas> --model Name

# Generate only service
python delphi-migrate-enhanced.py generate-service <file.pas> --model Name

# Verify output
python delphi-migrate-enhanced.py verify [--output dir]
```

## Success Criteria

Your migration is **rigorous** when:

✅ **100% Mode Coverage** - All I/U/D logic identified  
✅ **100% Permission Coverage** - All permission checks mapped  
✅ **95%+ Validation Coverage** - All 8 patterns detected  
✅ **100% Audit Coverage** - All LoggingData calls mapped  
✅ **<5% Manual Work** - Generated code is production-ready  

## Files Reference

| File | Purpose |
|------|---------|
| `parsers/pas_parser_enhanced.py` | Enhanced PAS parser with full pattern detection |
| `parsers/dfm_parser.py` | DFM form parser |
| `generators/request_generator.py` | FormRequest class generator |
| `generators/service_generator.py` | Service class generator |
| `generators/controller_generator_enhanced.py` | Controller generator |
| `generators/policy_generator.py` | Policy class generator |
| `generators/audit_log_generator.py` | AuditLog support generator |
| `delphi-migrate-enhanced.py` | Main CLI tool |

## Version History

- **v2.3.0** (2026-01-06): Agent Expert pattern with expertise.yaml & self-improve
- **v2.2.0** (2026-01-06): Added Prime Command & Self-Correcting Loop
- **v2.1.0** (2025-01-05): Added Required Reading Order & SOLID principles
- **v2.0.0** (2025-01-01): Full rewrite with complete pattern detection
- **v1.0.0**: Initial release with basic CRUD generation

---

**Use this Skill when:**
- ✅ Migrating Delphi VCL forms to Laravel
- ✅ Extracting business logic from Delphi applications
- ✅ Converting Delphi permission checks to Laravel authorization
- ✅ Translating Delphi validation rules to Laravel
- ✅ Building audit logging from LoggingData calls

**Do not use this Skill for:**
- ❌ Simple CRUD forms without complex business logic
- ❌ Third-party Delphi component migration
- ❌ Complex SQL stored procedures (manual review required)
